﻿namespace Sells_system.pages.sales_manage
{
    partial class factor_add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(factor_add));
            this.Fac_add = new System.Windows.Forms.Button();
            this.Fac_reset = new System.Windows.Forms.Button();
            this.fac_return = new System.Windows.Forms.Button();
            this.text_name = new System.Windows.Forms.TextBox();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.text_address = new System.Windows.Forms.TextBox();
            this.text_legel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Fac_add
            // 
            this.Fac_add.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Fac_add.Location = new System.Drawing.Point(85, 326);
            this.Fac_add.Name = "Fac_add";
            this.Fac_add.Size = new System.Drawing.Size(111, 47);
            this.Fac_add.TabIndex = 0;
            this.Fac_add.Text = "添加入库";
            this.Fac_add.UseVisualStyleBackColor = true;
            this.Fac_add.Click += new System.EventHandler(this.Fac_add_Click);
            // 
            // Fac_reset
            // 
            this.Fac_reset.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Fac_reset.Location = new System.Drawing.Point(278, 326);
            this.Fac_reset.Name = "Fac_reset";
            this.Fac_reset.Size = new System.Drawing.Size(111, 47);
            this.Fac_reset.TabIndex = 1;
            this.Fac_reset.Text = "清空重填";
            this.Fac_reset.UseVisualStyleBackColor = true;
            this.Fac_reset.Click += new System.EventHandler(this.Fac_reset_Click);
            // 
            // fac_return
            // 
            this.fac_return.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fac_return.Location = new System.Drawing.Point(460, 326);
            this.fac_return.Name = "fac_return";
            this.fac_return.Size = new System.Drawing.Size(111, 47);
            this.fac_return.TabIndex = 2;
            this.fac_return.Text = "返回";
            this.fac_return.UseVisualStyleBackColor = true;
            this.fac_return.Click += new System.EventHandler(this.Fac_return_Click);
            // 
            // text_name
            // 
            this.text_name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_name.Enabled = false;
            this.text_name.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_name.Location = new System.Drawing.Point(213, 66);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(358, 27);
            this.text_name.TabIndex = 3;
            // 
            // text_phone
            // 
            this.text_phone.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_phone.Location = new System.Drawing.Point(429, 146);
            this.text_phone.Name = "text_phone";
            this.text_phone.Size = new System.Drawing.Size(142, 27);
            this.text_phone.TabIndex = 4;
            // 
            // text_address
            // 
            this.text_address.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_address.Location = new System.Drawing.Point(213, 230);
            this.text_address.Name = "text_address";
            this.text_address.Size = new System.Drawing.Size(358, 27);
            this.text_address.TabIndex = 5;
            // 
            // text_legel
            // 
            this.text_legel.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_legel.Location = new System.Drawing.Point(213, 146);
            this.text_legel.Name = "text_legel";
            this.text_legel.Size = new System.Drawing.Size(103, 27);
            this.text_legel.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(359, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 27);
            this.label2.TabIndex = 8;
            this.label2.Text = "电话";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(80, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 27);
            this.label3.TabIndex = 9;
            this.label3.Text = "厂商地址";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(80, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 27);
            this.label4.TabIndex = 10;
            this.label4.Text = "法人代表";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(80, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 27);
            this.label1.TabIndex = 11;
            this.label1.Text = "厂商名称";
            // 
            // factor_add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 408);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.text_legel);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.fac_return);
            this.Controls.Add(this.Fac_reset);
            this.Controls.Add(this.Fac_add);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "factor_add";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " 添加供应商";
            this.Activated += new System.EventHandler(this.Fac_show);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Fac_add;
        private System.Windows.Forms.Button Fac_reset;
        private System.Windows.Forms.Button fac_return;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.TextBox text_legel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
    }
}