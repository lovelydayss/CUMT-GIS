﻿namespace Sells_system.pages
{
    partial class stocks_records
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(stocks_records));
            this.reset_sm = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.text_date_month = new System.Windows.Forms.TextBox();
            this.text_fac = new System.Windows.Forms.TextBox();
            this.text_id = new System.Windows.Forms.TextBox();
            this.text_value = new System.Windows.Forms.TextBox();
            this.text_employee = new System.Windows.Forms.TextBox();
            this.text_date_year = new System.Windows.Forms.TextBox();
            this.text_num = new System.Windows.Forms.TextBox();
            this.text_all_value = new System.Windows.Forms.TextBox();
            this.text_date_day = new System.Windows.Forms.TextBox();
            this.text_type = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.sr_return = new System.Windows.Forms.Button();
            this.add_sr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // reset_sm
            // 
            this.reset_sm.Location = new System.Drawing.Point(338, 364);
            this.reset_sm.Name = "reset_sm";
            this.reset_sm.Size = new System.Drawing.Size(111, 47);
            this.reset_sm.TabIndex = 52;
            this.reset_sm.Text = "清空重填";
            this.reset_sm.UseVisualStyleBackColor = true;
            this.reset_sm.Click += new System.EventHandler(this.Reset_sm_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(454, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 27);
            this.label4.TabIndex = 51;
            this.label4.Text = "型号：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(445, 289);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 27);
            this.label12.TabIndex = 50;
            this.label12.Text = "总金额";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(69, 291);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 27);
            this.label11.TabIndex = 49;
            this.label11.Text = "业务员编号：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(617, 237);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 27);
            this.label10.TabIndex = 48;
            this.label10.Text = "日";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(467, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 27);
            this.label9.TabIndex = 47;
            this.label9.Text = "月";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(307, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 27);
            this.label8.TabIndex = 46;
            this.label8.Text = "年";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(77, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 27);
            this.label7.TabIndex = 45;
            this.label7.Text = "进货日期：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(454, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 27);
            this.label6.TabIndex = 44;
            this.label6.Text = "数量：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(95, 184);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 27);
            this.label5.TabIndex = 43;
            this.label5.Text = "单价：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(77, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 27);
            this.label3.TabIndex = 42;
            this.label3.Text = "生产厂商：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(445, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 27);
            this.label2.TabIndex = 41;
            this.label2.Text = "商品名称：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(77, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 27);
            this.label1.TabIndex = 40;
            this.label1.Text = "进货编号：";
            // 
            // text_date_month
            // 
            this.text_date_month.Location = new System.Drawing.Point(391, 239);
            this.text_date_month.Name = "text_date_month";
            this.text_date_month.Size = new System.Drawing.Size(58, 27);
            this.text_date_month.TabIndex = 39;
            // 
            // text_fac
            // 
            this.text_fac.Location = new System.Drawing.Point(207, 115);
            this.text_fac.Name = "text_fac";
            this.text_fac.Size = new System.Drawing.Size(129, 27);
            this.text_fac.TabIndex = 38;
            // 
            // text_id
            // 
            this.text_id.Enabled = false;
            this.text_id.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_id.Location = new System.Drawing.Point(207, 51);
            this.text_id.Name = "text_id";
            this.text_id.Size = new System.Drawing.Size(129, 27);
            this.text_id.TabIndex = 37;
            // 
            // text_value
            // 
            this.text_value.Location = new System.Drawing.Point(207, 181);
            this.text_value.Name = "text_value";
            this.text_value.Size = new System.Drawing.Size(129, 27);
            this.text_value.TabIndex = 36;
            // 
            // text_employee
            // 
            this.text_employee.Location = new System.Drawing.Point(207, 291);
            this.text_employee.Name = "text_employee";
            this.text_employee.Size = new System.Drawing.Size(133, 27);
            this.text_employee.TabIndex = 35;
            // 
            // text_date_year
            // 
            this.text_date_year.Location = new System.Drawing.Point(229, 239);
            this.text_date_year.Name = "text_date_year";
            this.text_date_year.Size = new System.Drawing.Size(58, 27);
            this.text_date_year.TabIndex = 34;
            // 
            // text_num
            // 
            this.text_num.Location = new System.Drawing.Point(571, 181);
            this.text_num.Name = "text_num";
            this.text_num.Size = new System.Drawing.Size(142, 27);
            this.text_num.TabIndex = 33;
            // 
            // text_all_value
            // 
            this.text_all_value.Location = new System.Drawing.Point(571, 291);
            this.text_all_value.Name = "text_all_value";
            this.text_all_value.Size = new System.Drawing.Size(142, 27);
            this.text_all_value.TabIndex = 32;
            // 
            // text_date_day
            // 
            this.text_date_day.Location = new System.Drawing.Point(542, 239);
            this.text_date_day.Name = "text_date_day";
            this.text_date_day.Size = new System.Drawing.Size(58, 27);
            this.text_date_day.TabIndex = 31;
            // 
            // text_type
            // 
            this.text_type.Location = new System.Drawing.Point(571, 115);
            this.text_type.Name = "text_type";
            this.text_type.Size = new System.Drawing.Size(142, 27);
            this.text_type.TabIndex = 30;
            // 
            // text_name
            // 
            this.text_name.Location = new System.Drawing.Point(571, 51);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(142, 27);
            this.text_name.TabIndex = 29;
            // 
            // sr_return
            // 
            this.sr_return.Location = new System.Drawing.Point(551, 364);
            this.sr_return.Name = "sr_return";
            this.sr_return.Size = new System.Drawing.Size(111, 47);
            this.sr_return.TabIndex = 28;
            this.sr_return.Text = "返回";
            this.sr_return.UseVisualStyleBackColor = true;
            this.sr_return.Click += new System.EventHandler(this.Sr_return_Click_1);
            // 
            // add_sr
            // 
            this.add_sr.Location = new System.Drawing.Point(123, 364);
            this.add_sr.Name = "add_sr";
            this.add_sr.Size = new System.Drawing.Size(111, 47);
            this.add_sr.TabIndex = 27;
            this.add_sr.Text = "添加入库";
            this.add_sr.UseVisualStyleBackColor = true;
            this.add_sr.Click += new System.EventHandler(this.Add_sr_Click);
            // 
            // stocks_records
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 453);
            this.Controls.Add(this.reset_sm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.text_date_month);
            this.Controls.Add(this.text_fac);
            this.Controls.Add(this.text_id);
            this.Controls.Add(this.text_value);
            this.Controls.Add(this.text_employee);
            this.Controls.Add(this.text_date_year);
            this.Controls.Add(this.text_num);
            this.Controls.Add(this.text_all_value);
            this.Controls.Add(this.text_date_day);
            this.Controls.Add(this.text_type);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.sr_return);
            this.Controls.Add(this.add_sr);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "stocks_records";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "进货登记";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button reset_sm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_date_month;
        private System.Windows.Forms.TextBox text_fac;
        private System.Windows.Forms.TextBox text_id;
        private System.Windows.Forms.TextBox text_value;
        private System.Windows.Forms.TextBox text_employee;
        private System.Windows.Forms.TextBox text_date_year;
        private System.Windows.Forms.TextBox text_num;
        private System.Windows.Forms.TextBox text_all_value;
        private System.Windows.Forms.TextBox text_date_day;
        private System.Windows.Forms.TextBox text_type;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.Button sr_return;
        private System.Windows.Forms.Button add_sr;
    }
}